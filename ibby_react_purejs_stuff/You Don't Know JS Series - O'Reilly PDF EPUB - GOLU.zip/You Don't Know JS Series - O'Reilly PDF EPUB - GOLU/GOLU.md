#GOLU
> Keep Learning and help us to share the knowlege across the world. : )

-----
###Stuff you will..
* **_Love about us_**
 * Clean metadata whenever possible
* **_Despise about us_**
 * No seedbox.. So yeah that's right, speed might me slow.
 * You won't find content 0day, because of academics.

-----
###Changelog
* [June/15] Dropped .PNG, instead using .MD
* [May/14] On [Twitter @teamGOLU]
* Using .PNG
* On [TPB] a.k.a ThePirateBay
* On [KAT] a.k.a KickassTorrents

-----
###FAQ
1. Where the content comes from? **_That's simple.. Internet_**
2. Which means if it's not on the internet then it will not be on list? **_That's right Sherlock : )_**
3. Do you modify files? **_No modifications to files, just filtering metadata for clean ebooks_**
4. Do you take requests? **_Not at the moment_**
5. Which tools do you use? **_Acrobat, Indesign and Calibre_**
6. Heard you have a team? **_Yeah, 3 members. I, Spyguy and Xodus_**
7. I wanna help, how can I? **_That's so kind of you. BUY ebooks which are affordable to you and don't forget to SEED as long as possible_**

-----
Feel free to wink us on [Twitter @teamGOLU]  

> **Above info's are subjected to change, make sure you have recent updated .MD file. Cheers**

_That is all folks_  ; )

[Twitter @teamGOLU]:https://twitter.com/teamGOLU
[TPB]:https://thepiratebay.se/user/GOLU
[KAT]:https://kickass.to/user/GOLU