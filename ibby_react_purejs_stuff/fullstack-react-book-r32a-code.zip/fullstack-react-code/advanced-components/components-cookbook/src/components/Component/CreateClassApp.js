import React from 'react'

// React.createClass
const App = React.createClass({
  render: function() {} // required method
});

export default App
